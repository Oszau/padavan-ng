Бинари только в релизах. Собираем с исходников или качаем релиз с гитхаба ! Инфа по сборке в docs/compile.
Binaries are only in releases. Build from source or download release from github ! See docs/compile.
